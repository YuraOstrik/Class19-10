﻿using Microsoft.EntityFrameworkCore;

namespace MVCHome.Models
{
    public class FilmsContext : DbContext
    {
        public DbSet<Films> Films { get; set; }

        public FilmsContext(DbContextOptions<FilmsContext> options) : base(options)
        {
            if (Database.EnsureCreated())
            {
                Films?.Add(new Films { Name = "Inception", Director = "Christopher Nolan", Genre = "Sci-Fi", Year = 2010, Poster = "Images/films/inception.jpg", Description = "Dream invasion and manipulation." });
                Films?.Add(new Films { Name = "The Godfather", Director = "Francis Ford Coppola", Genre = "Crime", Year = 1972, Poster = "Images/films/godfather.jpg", Description = "Mafia family saga." });
                Films?.Add(new Films { Name = "The Dark Knight", Director = "Christopher Nolan", Genre = "Action", Year = 2008, Poster = "Images/films/dark_knight.jpg", Description = "Batman vs Joker." });
                Films?.Add(new Films { Name = "Pulp Fiction", Director = "Quentin Tarantino", Genre = "Crime", Year = 1994, Poster = "Images/films/pulp_fiction.jpg", Description = "Non-linear crime story." });
                Films?.Add(new Films { Name = "Interstellar", Director = "Christopher Nolan", Genre = "Sci-Fi", Year = 2014, Poster = "Images/films/interstellar.jpg", Description = "Space exploration and time." });
                SaveChanges();
            }
        }
    }
}
