﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace MVCHome.Models
{
    public class Films
    {
        public int id { get; set; }

        [Required(ErrorMessage = "Введите имя студента")]
        [Display(Name = "Name of Student")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Введите имя директора")]
        [Display(Name = "Name of Director")]
        public string Director { get; set; }
        [Required(ErrorMessage = "Введите название жанра")]
        [Display(Name = "Name of Genre")]
        public string Genre { get; set; }

        [Required(ErrorMessage = "Введите год выпуска фильма")]
        [Display(Name = "Enter Year")]
        [Range (1900, 2025, ErrorMessage = "Year is not correct")]
        public int Year { get; set; }


        [Required(ErrorMessage = "Нажмите и добавте постер")]
        [Display(Name = "Enter Poster")]
        public string Poster { get; set; }

        [Required(ErrorMessage = "Расскажите про фильм")]
        [Display(Name = "Enter Description")]
        public string Description { get; set; }
    }
}
